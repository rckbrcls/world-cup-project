# World Cup Database Project

Academic database project for SCC0640, based on `BD-Projeto-2026.pdf`.

The project models a FIFA World Cup management system in PostgreSQL and provides a Python command-line prototype for the required demonstrations.

## Scope

- PostgreSQL relational model for World Cup editions, teams, groups, matches, squads, referees, stadiums, events, and standings.
- SQL-first business rules through keys, constraints, functions, views, and triggers.
- Direct SQL data script for the demonstration dataset.
- Python terminal prototype that reads database login parameters, executes the 10 required reports, asks local Ollama to convert natural language to SQL, shows generated SQL before execution, and handles PostgreSQL errors.

This repository intentionally avoids extra product surfaces outside the course scope.

## Main Files

- `BD-Projeto-2026.pdf`: original course brief.
- `sql/ddl.sql`: schema, types, constraints, indexes, validation functions, and triggers.
- `sql/queries.sql`: SQL views and functions for the 10 required course queries.
- `sql/dml.sql`: direct demonstration dataset.
- `sql/verification.sql`: manual smoke checks and consistency queries.
- `world_cup_core/`: shared Python database, settings, Ollama, and SQL validation helpers.
- `world_cup_terminal/`: command-line prototype.
- `submission/`: course-delivery staging area with the required file names.

## Setup

Create a PostgreSQL database, then apply the SQL files in this order:

```bash
psql "$DATABASE_URL" -f sql/ddl.sql
psql "$DATABASE_URL" -f sql/queries.sql
psql "$DATABASE_URL" -f sql/dml.sql
```

Optional manual checks:

```bash
psql "$DATABASE_URL" -f sql/verification.sql
```

Install Python dependencies:

```bash
uv sync
```

The Python settings can be provided through `.env`:

```text
DATABASE_URL=postgresql://YOUR_DB_USER:YOUR_DB_PASSWORD@localhost:5432/world_cup
OLLAMA_BASE_URL=http://127.0.0.1:11434
OLLAMA_MODEL=gemma4:4b
OLLAMA_TIMEOUT_SECONDS=60
```

## Prototype

Run the terminal prototype with:

```bash
uv run world-cup-terminal
```

or:

```bash
uv run python -m world_cup_terminal
```

The prototype asks for host, port, database, user, and password. It then offers:

- database status
- the 10 required SQL reports
- natural-language-to-SQL planning through local Ollama
- controlled SQL execution with visible SQL and error handling

## Course Delivery

The course brief asks for these files in one zip:

1. `01.ER.pdf`
2. `02.ER.xml`
3. `03.Relacional.pdf`
4. `04.Relacional.xml`
5. `05.DDL.sql`
6. `06.DML.sql`
7. `07.Prototipo.zip`
8. `08.Instrucoes.txt`

The `submission/` folder stages those names. The diagram XML files are draw.io-compatible; the diagram PDFs must be exported from draw.io/diagrams.net before final submission.
